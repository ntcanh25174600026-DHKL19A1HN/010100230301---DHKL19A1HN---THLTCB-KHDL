n = int(input("Nhap n: "))
temp = n
tong = 0

while temp > 0:
    d = temp % 10
    tong = tong + d*d*d
    temp = temp // 10

if tong == n:
    print("La so Armstrong")
else:
    print("Khong phai")