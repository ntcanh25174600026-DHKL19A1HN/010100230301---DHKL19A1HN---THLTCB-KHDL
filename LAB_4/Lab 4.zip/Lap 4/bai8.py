n = int(input("Nhap n: "))

tong = 0
tich = 1
dao = 0

while n > 0:
    d = n % 10
    tong = tong + d
    tich = tich * d
    dao = dao * 10 + d
    n = n // 10

print("Tong:", tong)
print("Tich:", tich)
print("Dao:", dao)