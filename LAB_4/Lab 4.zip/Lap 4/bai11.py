n = int(input("Nhap n (n > 10): "))

# a) S1 = 6 + 6^2 + ... + 6^n
S1 = 0
a = 1
while a <= n:
    S1 = S1 + 6**a
    a = a + 1

# b) S2 = 1/3 + 1/3^2 + ... + 1/3^(2a+1)
S2 = 0
a = 1
while a <= n:
    S2 = S2 + 1/(3**a)
    a = a + 1

# c) S3 = -1^2 + 2^2 - 3^2 + ... + (-1)^a * a^2
S3 = 0
a = 1
while a <= n:
    S3 = S3 + ((-1)**a) * (a**2)
    a = a + 1

# d) S4 = 1*2*3 + 2*3*4 + ... + a(a+1)(a+2)
S4 = 0
a = 1
while a <= n:
    S4 = S4 + a*(a+1)*(a+2)
    a = a + 1

print("S1 =", S1)
print("S2 =", S2)
print("S3 =", S3)
print("S4 =", S4)