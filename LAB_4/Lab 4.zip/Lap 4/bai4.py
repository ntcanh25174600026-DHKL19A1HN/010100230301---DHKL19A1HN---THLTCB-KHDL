tong = 0
dem = 0
max_num = None

while True:
    n = int(input("Nhap so (0 de dung): "))
    
    if n == 0:
        break
    
    tong = tong + n
    dem = dem + 1
    
    if max_num is None or n > max_num:
        max_num = n