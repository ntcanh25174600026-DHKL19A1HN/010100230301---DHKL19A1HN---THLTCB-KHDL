while True:
    password = input("Nhap mat khau: ")
    
    if password == "123456":
        print("Dung mat khau!")
        break
    else:
        print("Sai, nhap lai!")
        